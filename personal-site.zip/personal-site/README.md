# Personal Website

A lightweight personal site inspired by the simplicity and link-first feel of austegard.com, but with an original layout and styling.

## Customize it

Open `index.html` and replace:

- `Your Name` and `YN`
- `YOUR-USERNAME` in the GitHub/LinkedIn links
- `you@example.com`
- the About text
- the three project cards
- the writing links
- the page title and meta description in `<head>`

You can change the main colors at the top of `styles.css`.

## Run locally

You can double-click `index.html`, or from this folder run:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

## Publish on GitHub Pages

1. Create a GitHub repository (for a user site, name it `YOUR-USERNAME.github.io`).
2. Upload these files to the repository root.
3. In GitHub: **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your default branch (usually `main`) and `/ (root)`, then save.

Because the site uses only relative file paths, it also works in a normal project Pages URL such as `YOUR-USERNAME.github.io/repository-name/`.

## Use your own domain

GitHub Pages can host the site while your own domain points to it.

1. In GitHub Pages settings, enter your custom domain.
2. Copy `CNAME.example` to a new file named exactly `CNAME` and replace its contents with your domain (for example, `www.example.com`). Commit that file.
3. At your domain registrar/DNS provider, follow GitHub's current Pages DNS instructions for the domain type you're using.
4. After DNS is working, enable **Enforce HTTPS** in GitHub Pages settings.

You can also host the same files on Netlify, Cloudflare Pages, Vercel, or nearly any ordinary web server because there is no build step.

## File structure

```text
personal-site/
├── index.html
├── styles.css
├── script.js
├── 404.html
├── CNAME.example
├── README.md
└── assets/
    └── favicon.svg
```
